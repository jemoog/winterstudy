printf("hi");
printf("hello");
piritf("why");
wow
whwfilkj
wf;clkj
