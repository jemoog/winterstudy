printf("hi");
printf("hello");
piritf("why");
wow
whwfilkj
wf;clkj
fb'ohsk
vdf;lkhskjvfk]
vd skjj gh'